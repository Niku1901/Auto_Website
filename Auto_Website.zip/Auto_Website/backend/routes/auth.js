const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/user');

const router = express.Router();

// 🔐 User Registration
router.post('/register', async (req, res) => {
  const { email, password } = req.body;

  try {
    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ email, password: hashed });
    await user.save();
    res.send('✅ Registration successful!');
  } catch (err) {
    res.status(400).send('❌ Email already exists or error!');
  }
});

// 🔑 User Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });
  if (!user) return res.status(404).send('❌ User not found');

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(401).send('🔒 Invalid password');

  const token = jwt.sign({ id: user._id }, 'niku-secret-key');
  res.json({ message: '✅ Login successful', token });
});

module.exports = router;