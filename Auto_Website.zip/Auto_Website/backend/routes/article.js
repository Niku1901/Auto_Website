const express = require('express');
const fs = require('fs');
const auth = require('../middleware/authMiddleware'); // Token check middleware

const router = express.Router();

// 🔐 Protected route: Only accessible with valid token
router.post('/add', auth, (req, res) => {
  const { title, content } = req.body;

  const newArticle = {
    title,
    content,
    createdBy: req.user.id, // Comes from decoded token
    timestamp: new Date()
  };

  let articles = [];

  // 🗂️ Read existing articles from data.json
  if (fs.existsSync('data.json')) {
    articles = JSON.parse(fs.readFileSync('data.json'));
  }

  // ➕ Add new article
  articles.push(newArticle);
  fs.writeFileSync('data.json', JSON.stringify(articles, null, 2));

  res.send('✅ Article uploaded securely!');
});

module.exports = router;